# Panduan Deploy Aplikasi Seleksi Paskibraka

## Persiapan Sebelum Deploy

1. **Ganti Password Admin Default**
   - Login sebagai admin
   - Ganti password di database atau buat akun admin baru

2. **Pindah ke Database Production**
   - SQLite cocok untuk development, tapi untuk production gunakan:
   - PostgreSQL (rekomendasi) atau MySQL
   - Update `DATABASE_URL` di `.env`

3. **Set Environment Variables**
   Buat file `.env` dengan:
   ```
   DATABASE_URL="postgresql://user:password@host:5432/paskibraka"
   NODE_ENV="production"
   ```

## Deploy ke Vercel (Rekomendasi)

1. Push kode ke GitHub
2. Buka vercel.com dan login
3. Klik "New Project"
4. Import dari GitHub
5. Set environment variables
6. Deploy!

## Deploy ke Railway

1. Buka railway.app
2. Connect GitHub
3. Pilih repository
4. Add PostgreSQL database
5. Set environment variables
6. Deploy!

## Perintah Build Production

```bash
# Build aplikasi
bun run build

# Generate Prisma Client
bunx prisma generate

# Push database schema
bunx prisma db push

# Seed data awal
bun run db:seed

# Jalankan production
bun run start
```

## Akun Default

- Admin: admin / admin123
- Peserta Demo: demo / demo

**PENTING: Ganti password setelah deploy!**
