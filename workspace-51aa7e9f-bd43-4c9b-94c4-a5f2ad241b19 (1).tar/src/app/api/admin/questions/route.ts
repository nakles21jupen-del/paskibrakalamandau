import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const questions = await db.question.findMany({
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(questions);
  } catch (error) {
    console.error('Get questions error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const { question, optionA, optionB, optionC, optionD, answer } = await request.json();

    if (!question || !optionA || !optionB || !optionC || !optionD || !answer) {
      return NextResponse.json(
        { error: 'Semua field harus diisi' },
        { status: 400 }
      );
    }

    if (!['A', 'B', 'C', 'D'].includes(answer)) {
      return NextResponse.json(
        { error: 'Jawaban harus A, B, C, atau D' },
        { status: 400 }
      );
    }

    const newQuestion = await db.question.create({
      data: {
        question,
        optionA,
        optionB,
        optionC,
        optionD,
        answer,
      },
    });

    return NextResponse.json({
      success: true,
      question: newQuestion,
    });
  } catch (error) {
    console.error('Create question error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}
