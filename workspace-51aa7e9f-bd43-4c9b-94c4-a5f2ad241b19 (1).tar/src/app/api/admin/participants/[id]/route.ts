import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { status } = await request.json();

    if (!['pending', 'approved', 'rejected'].includes(status)) {
      return NextResponse.json(
        { error: 'Status tidak valid' },
        { status: 400 }
      );
    }

    const participant = await db.participant.update({
      where: { id },
      data: { status },
    });

    return NextResponse.json({
      success: true,
      participant,
    });
  } catch (error) {
    console.error('Update participant error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // Get participant to find userId
    const participant = await db.participant.findUnique({
      where: { id },
      include: { user: true },
    });

    if (!participant) {
      return NextResponse.json(
        { error: 'Peserta tidak ditemukan' },
        { status: 404 }
      );
    }

    // Delete quiz results first (due to foreign key constraints)
    await db.quizResult.deleteMany({
      where: { participantId: id },
    });

    // Delete participant
    await db.participant.delete({
      where: { id },
    });

    // Delete associated user account
    if (participant.userId) {
      await db.participantUser.delete({
        where: { id: participant.userId },
      });
    }

    return NextResponse.json({ success: true, message: 'Akun peserta berhasil dihapus' });
  } catch (error) {
    console.error('Delete participant error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}
