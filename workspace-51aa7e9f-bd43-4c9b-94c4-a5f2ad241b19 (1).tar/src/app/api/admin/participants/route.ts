import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const participants = await db.participant.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        quizResults: {
          orderBy: { completedAt: 'desc' },
          take: 1, // Get only the latest quiz result
        },
      },
    });

    // Transform the data to include quiz result as a flat field
    const participantsWithScore = participants.map((p) => ({
      ...p,
      quizScore: p.quizResults.length > 0 ? p.quizResults[0].score : null,
      quizCorrectAnswers: p.quizResults.length > 0 ? p.quizResults[0].correctAnswers : null,
      quizTotalQuestions: p.quizResults.length > 0 ? p.quizResults[0].totalQuestions : null,
      quizTimeSpent: p.quizResults.length > 0 ? p.quizResults[0].timeSpent : null,
      quizCompletedAt: p.quizResults.length > 0 ? p.quizResults[0].completedAt : null,
    }));

    return NextResponse.json(participantsWithScore);
  } catch (error) {
    console.error('Get participants error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}
