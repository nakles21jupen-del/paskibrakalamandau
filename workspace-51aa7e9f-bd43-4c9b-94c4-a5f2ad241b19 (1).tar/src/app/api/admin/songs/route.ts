import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const songs = await db.nationalSong.findMany({
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json(songs);
  } catch (error) {
    console.error('Get songs error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const { title, audioUrl } = await request.json();

    if (!title || !audioUrl) {
      return NextResponse.json(
        { error: 'Judul dan URL audio harus diisi' },
        { status: 400 }
      );
    }

    const song = await db.nationalSong.create({
      data: {
        title,
        audioUrl,
      },
    });

    return NextResponse.json({
      success: true,
      song,
    });
  } catch (error) {
    console.error('Create song error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}
