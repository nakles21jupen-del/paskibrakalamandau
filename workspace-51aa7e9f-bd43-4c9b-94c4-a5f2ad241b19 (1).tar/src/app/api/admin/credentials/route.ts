import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    let admin = await db.admin.findFirst();

    // If no admin exists, create default admin for demo
    if (!admin) {
      admin = await db.admin.create({
        data: {
          username: 'admin',
          password: 'admin123',
        },
      });
    }

    return NextResponse.json({
      username: admin.username,
      // Don't return the actual password for security
      hasPassword: !!admin.password,
    });
  } catch (error) {
    console.error('Get admin credentials error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const { currentPassword, newUsername, newPassword } = await request.json();

    if (!currentPassword) {
      return NextResponse.json(
        { error: 'Password saat ini harus diisi' },
        { status: 400 }
      );
    }

    if (!newUsername && !newPassword) {
      return NextResponse.json(
        { error: 'Username atau password baru harus diisi' },
        { status: 400 }
      );
    }

    // Get current admin
    let admin = await db.admin.findFirst();

    // If no admin exists, create default admin for demo
    if (!admin) {
      admin = await db.admin.create({
        data: {
          username: 'admin',
          password: 'admin123',
        },
      });
    }

    // Verify current password
    if (admin.password !== currentPassword) {
      return NextResponse.json(
        { error: 'Password saat ini salah' },
        { status: 401 }
      );
    }

    // Update admin credentials
    const updateData: { username?: string; password?: string } = {};
    
    if (newUsername && newUsername.trim() !== '') {
      // Check if username already exists (if changing username)
      if (newUsername !== admin.username) {
        const existingAdmin = await db.admin.findUnique({
          where: { username: newUsername },
        });
        if (existingAdmin) {
          return NextResponse.json(
            { error: 'Username sudah digunakan' },
            { status: 400 }
          );
        }
      }
      updateData.username = newUsername.trim();
    }
    
    if (newPassword && newPassword.trim() !== '') {
      if (newPassword.length < 6) {
        return NextResponse.json(
          { error: 'Password baru minimal 6 karakter' },
          { status: 400 }
        );
      }
      updateData.password = newPassword;
    }

    await db.admin.update({
      where: { id: admin.id },
      data: updateData,
    });

    return NextResponse.json({
      success: true,
      message: 'Kredensial berhasil diperbarui',
    });
  } catch (error) {
    console.error('Update admin credentials error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}
