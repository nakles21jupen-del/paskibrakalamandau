import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

// Create a new PrismaClient instance
const prisma = new PrismaClient();

// Default settings
const defaultSettings = [
  { key: 'site_title', value: 'Seleksi Paskibraka', description: 'Judul utama website' },
  { key: 'site_subtitle', value: 'Panji-Panji Garuda Indonesia', description: 'Subjudul website' },
  { key: 'badge_merah', value: 'Merah', description: 'Teks badge merah' },
  { key: 'badge_putih', value: 'Putih', description: 'Teks badge putih' },
  { key: 'button_masuk', value: 'Masuk', description: 'Teks tombol masuk' },
  { key: 'button_buat_akun', value: 'Buat Akun', description: 'Teks tombol buat akun' },
  { key: 'button_admin', value: 'Admin Panel', description: 'Teks tombol admin' },
  { key: 'footer_text', value: '© 2024 Seleksi Paskibraka - Panji-Panji Garuda Indonesia', description: 'Teks footer' },
  { key: 'login_title', value: 'Login Peserta', description: 'Judul halaman login' },
  { key: 'login_subtitle', value: 'Masukkan kredensial akun Anda', description: 'Subjudul halaman login' },
  { key: 'register_title', value: 'Pendaftaran Peserta', description: 'Judul halaman registrasi' },
  { key: 'register_subtitle', value: 'Lengkapi data diri Anda untuk mendaftar seleksi Paskibraka', description: 'Subjudul halaman registrasi' },
  { key: 'admin_title', value: 'Admin Panel - Paskibraka', description: 'Judul admin panel' },
  // Quiz settings
  { key: 'quiz_duration', value: '30', description: 'Durasi pengerjaan soal (menit)' },
  { key: 'quiz_passing_score', value: '70', description: 'Nilai minimal lulus (%)' },
  { key: 'quiz_title', value: 'Ujian Seleksi Paskibraka', description: 'Judul halaman ujian' },
];

// Initialize default settings if not exist
async function initializeSettings() {
  for (const setting of defaultSettings) {
    const existing = await prisma.setting.findUnique({
      where: { key: setting.key },
    });
    if (!existing) {
      await prisma.setting.create({
        data: setting,
      });
    }
  }
}

// GET - Fetch all settings
export async function GET() {
  try {
    await initializeSettings();
    
    const settings = await prisma.setting.findMany({
      orderBy: { key: 'asc' },
    });
    
    return NextResponse.json(settings);
  } catch (error) {
    console.error('Error fetching settings:', error);
    return NextResponse.json(
      { error: 'Gagal mengambil pengaturan' },
      { status: 500 }
    );
  }
}

// PUT - Update a setting
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { key, value, description } = body;

    if (!key || value === undefined) {
      return NextResponse.json(
        { error: 'Key dan value harus diisi' },
        { status: 400 }
      );
    }

    const setting = await prisma.setting.upsert({
      where: { key },
      update: { value, description },
      create: { key, value, description },
    });

    return NextResponse.json(setting);
  } catch (error) {
    console.error('Error updating setting:', error);
    return NextResponse.json(
      { error: 'Gagal memperbarui pengaturan' },
      { status: 500 }
    );
  }
}
