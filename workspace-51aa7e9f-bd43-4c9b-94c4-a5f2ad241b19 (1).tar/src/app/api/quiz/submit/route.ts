import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

interface Answer {
  questionId: string;
  answer: string;
}

// POST - Submit quiz answers and calculate score
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { participantId, answers, timeSpent } = body as { 
      participantId: string; 
      answers: Answer[];
      timeSpent: number;
    };

    if (!participantId || !answers || !Array.isArray(answers)) {
      return NextResponse.json({ error: 'Data tidak valid' }, { status: 400 });
    }

    // Get all questions with correct answers
    const questions = await prisma.question.findMany({
      where: { isActive: true },
      select: { id: true, answer: true },
    });

    // Calculate score
    let correctAnswers = 0;
    for (const answer of answers) {
      const question = questions.find(q => q.id === answer.questionId);
      if (question && question.answer === answer.answer) {
        correctAnswers++;
      }
    }

    const totalQuestions = questions.length;
    const score = totalQuestions > 0 ? Math.round((correctAnswers / totalQuestions) * 100) : 0;

    // Save result
    const result = await prisma.quizResult.create({
      data: {
        participantId,
        score,
        totalQuestions,
        correctAnswers,
        timeSpent,
      },
    });

    return NextResponse.json({
      success: true,
      result: {
        id: result.id,
        score,
        totalQuestions,
        correctAnswers,
        timeSpent,
      },
    });
  } catch (error) {
    console.error('Error submitting quiz:', error);
    return NextResponse.json({ error: 'Gagal menyimpan hasil quiz' }, { status: 500 });
  }
}
