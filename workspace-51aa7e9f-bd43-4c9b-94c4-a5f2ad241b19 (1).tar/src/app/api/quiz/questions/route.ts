import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET - Fetch active quiz questions for participants (without answers)
export async function GET() {
  try {
    const questions = await prisma.question.findMany({
      where: { isActive: true },
      select: {
        id: true,
        question: true,
        optionA: true,
        optionB: true,
        optionC: true,
        optionD: true,
        // Don't include answer!
      },
      orderBy: { createdAt: 'asc' },
    });

    return NextResponse.json(questions);
  } catch (error) {
    console.error('Error fetching quiz questions:', error);
    return NextResponse.json({ error: 'Gagal mengambil soal' }, { status: 500 });
  }
}
