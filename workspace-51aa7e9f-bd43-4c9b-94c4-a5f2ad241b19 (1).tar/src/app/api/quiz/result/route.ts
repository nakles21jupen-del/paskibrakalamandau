import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET - Fetch quiz result for participant
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const participantId = searchParams.get('participantId');

    if (!participantId) {
      return NextResponse.json({ error: 'Participant ID diperlukan' }, { status: 400 });
    }

    const result = await prisma.quizResult.findFirst({
      where: { participantId },
      orderBy: { completedAt: 'desc' },
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error fetching quiz result:', error);
    return NextResponse.json({ error: 'Gagal mengambil hasil quiz' }, { status: 500 });
  }
}
