import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { fullName, participantNumber, email, school } = await request.json();

    // Validation
    if (!fullName || !participantNumber || !email || !school) {
      return NextResponse.json(
        { error: 'Semua field harus diisi' },
        { status: 400 }
      );
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Format email tidak valid' },
        { status: 400 }
      );
    }

    // Check if participant number already exists
    const existingParticipant = await db.participant.findUnique({
      where: { participantNumber },
    });

    if (existingParticipant) {
      return NextResponse.json(
        { error: 'Nomor peserta sudah terdaftar' },
        { status: 400 }
      );
    }

    // Create or get user (for demo, create a default user)
    let user = await db.participantUser.findFirst();
    
    if (!user) {
      // Create a demo user for testing
      user = await db.participantUser.create({
        data: {
          username: 'peserta_demo',
          password: 'demo123',
        },
      });
    }

    // Create participant
    const participant = await db.participant.create({
      data: {
        fullName,
        participantNumber,
        email,
        school,
        userId: user.id,
      },
    });

    return NextResponse.json({
      success: true,
      participant: {
        id: participant.id,
        fullName: participant.fullName,
        participantNumber: participant.participantNumber,
        email: participant.email,
        school: participant.school,
      },
    });
  } catch (error) {
    console.error('Create participant error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}
