import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json();

    if (!username || !password) {
      return NextResponse.json(
        { error: 'Username dan password harus diisi' },
        { status: 400 }
      );
    }

    const user = await db.participantUser.findUnique({
      where: { username },
      include: { participant: true },
    });

    if (!user || user.password !== password) {
      return NextResponse.json(
        { error: 'Username atau password salah' },
        { status: 401 }
      );
    }

    if (!user.participant) {
      return NextResponse.json(
        { error: 'Data peserta tidak ditemukan' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      participant: {
        id: user.participant.id,
        username: user.participant.username,
        email: user.participant.email,
        fullName: user.participant.fullName,
        placeOfBirth: user.participant.placeOfBirth,
        dateOfBirth: user.participant.dateOfBirth,
        gender: user.participant.gender,
        religion: user.participant.religion,
        height: user.participant.height,
        weight: user.participant.weight,
        school: user.participant.school,
        class: user.participant.class,
        phone: user.participant.phone,
        address: user.participant.address,
        status: user.participant.status,
        createdAt: user.participant.createdAt,
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}
