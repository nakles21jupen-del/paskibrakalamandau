import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const data = await request.json();

    // Extract all fields
    const {
      // Data Akun
      username,
      password,
      email,
      // Data Diri
      fullName,
      placeOfBirth,
      dateOfBirth,
      gender,
      religion,
      // Data Fisik
      height,
      weight,
      // Data Sekolah
      school,
      class: classGrade,
      // Data Kontak
      phone,
      address,
    } = data;

    // Validation
    if (!username || username.length < 4) {
      return NextResponse.json(
        { error: 'Username minimal 4 karakter' },
        { status: 400 }
      );
    }

    if (!password || password.length < 6) {
      return NextResponse.json(
        { error: 'Password minimal 6 karakter' },
        { status: 400 }
      );
    }

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json(
        { error: 'Format email tidak valid' },
        { status: 400 }
      );
    }

    // Check if username already exists
    const existingUser = await db.participantUser.findUnique({
      where: { username },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'Username sudah digunakan' },
        { status: 400 }
      );
    }

    // Create user account
    const user = await db.participantUser.create({
      data: {
        username,
        password,
      },
    });

    // Create participant profile
    const participant = await db.participant.create({
      data: {
        // Data Akun
        username,
        email,
        // Data Diri
        fullName,
        placeOfBirth,
        dateOfBirth,
        gender,
        religion,
        // Data Fisik
        height,
        weight,
        // Data Sekolah
        school,
        class: classGrade,
        // Data Kontak
        phone,
        address,
        // Link to user
        userId: user.id,
      },
    });

    return NextResponse.json({
      success: true,
      participant: {
        id: participant.id,
        fullName: participant.fullName,
        username: participant.username,
      },
    });
  } catch (error) {
    console.error('Register error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}
