import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

// Create a new PrismaClient instance - v2
const prisma = new PrismaClient();

// Default settings
const defaultSettings = [
  { key: 'site_title', value: 'Seleksi Paskibraka' },
  { key: 'site_subtitle', value: 'Panji-Panji Garuda Indonesia' },
  { key: 'badge_merah', value: 'Merah' },
  { key: 'badge_putih', value: 'Putih' },
  { key: 'button_masuk', value: 'Masuk' },
  { key: 'button_buat_akun', value: 'Buat Akun' },
  { key: 'button_admin', value: 'Admin Panel' },
  { key: 'footer_text', value: '© 2024 Seleksi Paskibraka - Panji-Panji Garuda Indonesia' },
  { key: 'login_title', value: 'Login Peserta' },
  { key: 'login_subtitle', value: 'Masukkan kredensial akun Anda' },
  { key: 'register_title', value: 'Pendaftaran Peserta' },
  { key: 'register_subtitle', value: 'Lengkapi data diri Anda untuk mendaftar seleksi Paskibraka' },
  { key: 'admin_title', value: 'Admin Panel - Paskibraka' },
  // Quiz settings
  { key: 'quiz_duration', value: '30' },
  { key: 'quiz_passing_score', value: '70' },
  { key: 'quiz_title', value: 'Ujian Seleksi Paskibraka' },
];

// Initialize default settings if not exist
async function initializeSettings() {
  for (const setting of defaultSettings) {
    const existing = await prisma.setting.findUnique({
      where: { key: setting.key },
    });
    if (!existing) {
      await prisma.setting.create({
        data: { key: setting.key, value: setting.value },
      });
    }
  }
}

// GET - Fetch all settings as key-value object
export async function GET() {
  try {
    await initializeSettings();
    
    const settings = await prisma.setting.findMany({
      select: { key: true, value: true },
    });
    
    // Convert to key-value object for easy use
    const settingsObj: Record<string, string> = {};
    for (const setting of settings) {
      settingsObj[setting.key] = setting.value;
    }
    
    return NextResponse.json(settingsObj);
  } catch (error) {
    console.error('Error fetching settings:', error);
    return NextResponse.json({});
  }
}
