'use client';

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { 
  Shield, User, Lock, ArrowLeft, Send, AlertCircle, CheckCircle2, 
  Volume2, VolumeX, Users, FileQuestion, Download, Plus, Trash2,
  LogOut, Settings, Music, ChevronRight, Eye, EyeOff, UserPlus,
  Clock, Megaphone, Trophy, Play, ClipboardList
} from 'lucide-react';
import { toast } from 'sonner';

// Types
type Page = 'landing' | 'login' | 'register' | 'dashboard' | 'quiz' | 'admin-login' | 'admin';

interface Participant {
  id: string;
  username: string;
  email: string;
  fullName: string;
  placeOfBirth: string;
  dateOfBirth: string;
  gender: string;
  religion: string;
  height: string;
  weight: string;
  school: string;
  class: string;
  phone: string;
  address: string;
  status: string;
  createdAt: string;
  quizScore: number | null;
  quizCorrectAnswers: number | null;
  quizTotalQuestions: number | null;
  quizTimeSpent: number | null;
  quizCompletedAt: string | null;
}

interface Question {
  id: string;
  question: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  answer?: string;
  isActive: boolean;
}

interface Song {
  id: string;
  title: string;
  audioUrl: string;
  isActive: boolean;
}

interface Announcement {
  id: string;
  title: string;
  content: string;
  isActive: boolean;
  createdAt: string;
}

interface QuizResult {
  id: string;
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  timeSpent: number;
  completedAt: string;
}

interface AppSettings {
  site_title: string;
  site_subtitle: string;
  badge_merah: string;
  badge_putih: string;
  button_masuk: string;
  button_buat_akun: string;
  button_admin: string;
  footer_text: string;
  login_title: string;
  login_subtitle: string;
  register_title: string;
  register_subtitle: string;
  admin_title: string;
  quiz_duration: string;
  quiz_passing_score: string;
  quiz_title: string;
  [key: string]: string;
}

// Announcement Banner Component
const AnnouncementBanner = ({ announcements }: { announcements: Announcement[] }) => {
  if (announcements.length === 0) return null;

  return (
    <div className="bg-yellow-500 text-black py-2 px-2 md:px-4">
      <div className="container mx-auto">
        {announcements.map((ann) => (
          <div key={ann.id} className="flex items-center gap-1 md:gap-2 text-xs md:text-sm">
            <Megaphone className="w-3 h-3 md:w-4 md:h-4 flex-shrink-0" />
            <span className="font-semibold truncate">{ann.title}:</span>
            <span className="truncate hidden sm:inline">{ann.content}</span>
            <span className="truncate sm:hidden">{ann.content.substring(0, 30)}...</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default function PaskibrakaSelection() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const [currentUser, setCurrentUser] = useState<Participant | null>(null);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  
  const [settings, setSettings] = useState<AppSettings>({
    site_title: 'Seleksi Paskibraka',
    site_subtitle: 'Panji-Panji Garuda Indonesia',
    badge_merah: 'Merah',
    badge_putih: 'Putih',
    button_masuk: 'Masuk',
    button_buat_akun: 'Buat Akun',
    button_admin: 'Admin Panel',
    footer_text: '© 2024 Seleksi Paskibraka - Panji-Panji Garuda Indonesia',
    login_title: 'Login Peserta',
    login_subtitle: 'Masukkan kredensial akun Anda',
    register_title: 'Pendaftaran Peserta',
    register_subtitle: 'Lengkapi data diri Anda untuk mendaftar seleksi Paskibraka',
    admin_title: 'Admin Panel - Paskibraka',
    quiz_duration: '30',
    quiz_passing_score: '70',
    quiz_title: 'Ujian Seleksi Paskibraka',
  });

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const res = await fetch('/api/settings');
        if (res.ok) {
          const data = await res.json();
          setSettings(prev => ({ ...prev, ...data }));
        }
      } catch (error) {
        console.error('Failed to fetch settings');
      }
    };
    
    const fetchAnnouncements = async () => {
      try {
        const res = await fetch('/api/announcements');
        if (res.ok) {
          const data = await res.json();
          setAnnouncements(data);
        }
      } catch (error) {
        console.error('Failed to fetch announcements');
      }
    };
    
    fetchSettings();
    fetchAnnouncements();
  }, []);

  // Paskibraka Logo Component
  const PaskibrakaLogo = ({ size = 128 }: { size?: number }) => (
    <img 
      src="/logo-paskibraka.png" 
      alt="Logo Paskibraka" 
      width={size} 
      height={size}
      className="drop-shadow-2xl object-contain"
      style={{ width: size, height: size }}
    />
  );

  // Indonesia Map SVG Component - More Detailed
  const IndonesiaMap = () => (
    <svg 
      viewBox="0 0 1000 350" 
      className="w-full max-w-6xl opacity-15"
      style={{ filter: 'drop-shadow(0 0 30px rgba(255,255,255,0.4))' }}
    >
      {/* Sumatera - More detailed shape */}
      <path d="M30,120 Q40,90 60,100 Q75,70 95,85 Q110,65 130,75 Q145,60 165,75 L180,95 Q185,120 175,145 Q160,170 140,175 Q120,185 100,175 Q75,180 55,160 Q35,145 30,120Z
               M170,95 Q185,90 195,100 Q205,95 210,105 L215,120 Q210,135 195,130 Q180,135 175,145 Q165,140 170,120Z" 
        fill="white"/>
      
      {/* Java - Elongated island */}
      <path d="M220,180 Q260,165 320,170 Q380,175 440,168 Q480,175 520,170 Q540,178 520,185 Q480,195 420,188 Q360,195 300,188 Q250,195 220,180Z" 
        fill="white"/>
      
      {/* Kalimantan - Large island */}
      <path d="M340,50 Q390,35 440,45 Q490,55 510,85 Q520,120 495,145 Q460,165 410,155 Q360,145 340,110 Q325,75 340,50Z
               M510,85 Q530,80 545,90 Q555,100 545,115 Q530,125 510,120 Q500,105 510,85Z" 
        fill="white"/>
      
      {/* Sulawesi - K-shaped island */}
      <path d="M560,55 Q585,45 600,55 Q615,45 630,55 L640,75 Q650,65 665,75 Q680,65 695,80 L700,100 Q690,115 675,105 Q660,115 645,105 Q630,120 615,110 Q595,115 580,100 Q565,90 560,55Z
               M630,55 Q645,50 655,60 Q660,75 650,85 Q635,80 630,70Z
               M665,75 Q680,85 690,100 Q685,115 670,110 Q660,95 665,75Z" 
        fill="white"/>
      
      {/* Maluku Islands - Chain of small islands */}
      <path d="M720,70 Q740,60 755,70 Q765,80 780,70 Q795,80 805,72 L810,85 Q800,98 785,90 Q770,100 755,92 Q735,100 720,88 Q710,78 720,70Z
               M810,85 Q825,80 835,90 Q840,100 830,108 Q815,105 810,95Z" 
        fill="white"/>
      
      {/* Papua - Large eastern island */}
      <path d="M850,40 Q900,25 950,35 Q980,55 975,85 Q960,110 920,105 Q880,110 855,85 Q840,60 850,40Z
               M950,35 Q970,30 985,40 Q995,55 985,70 Q970,75 955,65 Q945,50 950,35Z" 
        fill="white"/>
      
      {/* Bali & Nusa Tenggara - Island chain */}
      <path d="M545,190 Q565,182 580,188 Q595,195 615,188 Q635,196 655,190 Q675,198 695,192 Q710,200 700,208 Q680,218 655,212 Q630,220 605,213 Q580,220 555,212 Q535,215 545,190Z" 
        fill="white"/>
      
      {/* Smaller islands */}
      <circle cx="215" cy="165" r="5" fill="white"/>
      <circle cx="535" cy="175" r="4" fill="white"/>
      <circle cx="700" cy="65" r="4" fill="white"/>
      <circle cx="625" cy="130" r="3" fill="white"/>
    </svg>
  );

  // Landing Page Component
  const LandingPage = () => (
    <div className="min-h-screen flex flex-col relative overflow-hidden">
      <div className="absolute inset-0 animate-gradient-red-white opacity-80" />
      <div className="absolute inset-0 animate-stripe opacity-30" />
      
      {/* Indonesia Map Background - Full screen */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden">
        <div className="absolute bottom-0 translate-y-1/3 scale-125">
          <IndonesiaMap />
        </div>
        {/* Additional map overlay for depth */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-white/5 blur-3xl"/>
          <div className="absolute bottom-1/4 right-1/4 w-48 h-48 rounded-full bg-white/5 blur-3xl"/>
        </div>
      </div>
      
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center p-6">
        <motion.div 
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ duration: 0.8, type: 'spring' }}
          className="mb-8"
        >
          <div className="relative animate-float">
            <PaskibrakaLogo size={128} />
          </div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-6xl font-bold text-white drop-shadow-lg mb-4">
            {settings.site_title}
          </h1>
          <p className="text-xl md:text-2xl text-white/90 font-medium">
            {settings.site_subtitle}
          </p>
          <div className="mt-4 flex items-center justify-center gap-2">
            <Badge variant="outline" className="bg-red-600 text-white border-white/30 text-lg px-4 py-1">
              {settings.badge_merah}
            </Badge>
            <Badge variant="outline" className="bg-white text-red-600 border-red-600 text-lg px-4 py-1">
              {settings.badge_putih}
            </Badge>
          </div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          <Button 
            size="lg" 
            onClick={() => setCurrentPage('login')}
            className="bg-white text-red-600 hover:bg-red-50 font-bold text-xl px-10 py-6 rounded-xl shadow-2xl animate-pulse-glow border-2 border-red-200"
          >
            <User className="mr-3 w-6 h-6" />
            {settings.button_masuk}
          </Button>
          
          <Button 
            size="lg" 
            onClick={() => setCurrentPage('register')}
            className="bg-red-600 text-white hover:bg-red-700 font-bold text-xl px-10 py-6 rounded-xl shadow-2xl border-2 border-white/30"
          >
            <UserPlus className="mr-3 w-6 h-6" />
            {settings.button_buat_akun}
          </Button>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="mt-6"
        >
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setCurrentPage('admin-login')}
            className="text-white/70 hover:text-white hover:bg-white/10"
          >
            <Settings className="mr-2 w-4 h-4" />
            {settings.button_admin}
          </Button>
        </motion.div>
      </div>
      
      <footer className="relative z-10 bg-black/20 backdrop-blur-sm py-4 text-center text-white/80">
        <p>{settings.footer_text}</p>
      </footer>
    </div>
  );

  // Login Page Component
  const LoginPage = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    useEffect(() => {
      if (audioEnabled && audioRef.current) {
        audioRef.current.play().catch(() => {});
        setIsAudioPlaying(true);
      }
    }, [audioEnabled]);

    const handleLogin = async (e: React.FormEvent) => {
      e.preventDefault();
      setError('');
      setLoading(true);

      try {
        const res = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password }),
        });

        const data = await res.json();

        if (res.ok) {
          setCurrentUser(data.participant);
          toast.success('Login berhasil!');
          setCurrentPage('dashboard');
        } else {
          setError(data.error || 'Username atau password salah');
        }
      } catch {
        setError('Terjadi kesalahan. Silakan coba lagi.');
      } finally {
        setLoading(false);
      }
    };

    return (
      <div className="min-h-screen flex flex-col relative overflow-hidden">
        <div className="absolute inset-0 animate-gradient-red-white opacity-70" />
        
        <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={() => {
              setAudioEnabled(!audioEnabled);
              if (audioRef.current) {
                if (!audioEnabled) {
                  audioRef.current.play().catch(() => {});
                } else {
                  audioRef.current.pause();
                }
              }
            }}
            className="bg-white/90 hover:bg-white"
          >
            {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </Button>
        </div>

        <div className="relative z-10 flex-1 flex items-center justify-center p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="w-full max-w-md bg-white/95 backdrop-blur-lg shadow-2xl">
              <CardHeader className="text-center">
                <motion.div 
                  initial={{ y: -20 }}
                  animate={{ y: 0 }}
                  className="flex justify-center mb-4"
                >
                  <PaskibrakaLogo size={64} />
                </motion.div>
                <CardTitle className="text-2xl font-bold text-red-700">{settings.login_title}</CardTitle>
                <CardDescription>{settings.login_subtitle}</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleLogin} className="space-y-4">
                  {error && (
                    <Alert variant="destructive" className="bg-red-50 border-red-200">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="username">Username</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                      <Input
                        id="username"
                        type="text"
                        placeholder="Masukkan username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="pl-10"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="password">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Masukkan password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="pl-10 pr-10"
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 top-1 h-7 w-7"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setCurrentPage('landing');
                        if (audioRef.current) {
                          audioRef.current.pause();
                          setIsAudioPlaying(false);
                        }
                      }}
                      className="flex-1"
                    >
                      <ArrowLeft className="mr-2 w-4 h-4" />
                      Kembali
                    </Button>
                    <Button 
                      type="submit" 
                      className="flex-1 bg-red-600 hover:bg-red-700"
                      disabled={loading}
                    >
                      {loading ? 'Memproses...' : 'Masuk'}
                    </Button>
                  </div>
                  
                  <div className="mt-6 text-center">
                    <p className="text-gray-600 text-sm">
                      Belum punya akun?{' '}
                      <Button
                        type="button"
                        variant="link"
                        className="p-0 h-auto text-red-600 hover:text-red-700 font-medium"
                        onClick={() => setCurrentPage('register')}
                      >
                        Daftar Sekarang
                      </Button>
                    </p>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        <audio ref={audioRef} loop>
          <source src="/indonesia-raya.mp3" type="audio/mpeg" />
        </audio>
      </div>
    );
  };

  // Register Page Component
  const RegisterPage = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [email, setEmail] = useState('');
    const [fullName, setFullName] = useState('');
    const [placeOfBirth, setPlaceOfBirth] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState('');
    const [gender, setGender] = useState('');
    const [religion, setReligion] = useState('');
    const [height, setHeight] = useState('');
    const [weight, setWeight] = useState('');
    const [school, setSchool] = useState('');
    const [classGrade, setClassGrade] = useState('');
    const [phone, setPhone] = useState('');
    const [address, setAddress] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);

    const validateForm = () => {
      if (!username.trim() || username.length < 4) {
        setError('Username minimal 4 karakter');
        return false;
      }
      if (!password || password.length < 6) {
        setError('Password minimal 6 karakter');
        return false;
      }
      if (password !== confirmPassword) {
        setError('Konfirmasi password tidak cocok');
        return false;
      }
      if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        setError('Format email tidak valid');
        return false;
      }
      if (!fullName.trim() || !placeOfBirth.trim() || !dateOfBirth) {
        setError('Data diri harus lengkap');
        return false;
      }
      if (!gender || !religion) {
        setError('Jenis kelamin dan agama harus diisi');
        return false;
      }
      if (!height.trim() || !weight.trim()) {
        setError('Tinggi dan berat badan harus diisi');
        return false;
      }
      if (!school.trim() || !classGrade.trim()) {
        setError('Data sekolah harus lengkap');
        return false;
      }
      if (!phone.trim() || !address.trim()) {
        setError('Nomor telepon dan alamat harus diisi');
        return false;
      }
      return true;
    };

    const handleRegister = async (e: React.FormEvent) => {
      e.preventDefault();
      setError('');

      if (!validateForm()) return;

      setLoading(true);

      try {
        const res = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username, password, email,
            fullName, placeOfBirth, dateOfBirth, gender, religion,
            height, weight, school, class: classGrade,
            phone, address,
          }),
        });

        const data = await res.json();

        if (res.ok) {
          setSuccess(true);
          toast.success('Pendaftaran berhasil!');
        } else {
          setError(data.error || 'Gagal membuat akun');
        }
      } catch {
        setError('Terjadi kesalahan. Silakan coba lagi.');
      } finally {
        setLoading(false);
      }
    };

    if (success) {
      return (
        <div className="min-h-screen flex flex-col relative overflow-hidden">
          <div className="absolute inset-0 animate-gradient-red-white opacity-70" />
          <div className="relative z-10 flex-1 flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="text-center"
            >
              <Card className="w-full max-w-md bg-white/95 backdrop-blur-lg shadow-2xl">
                <CardContent className="pt-8 pb-8">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', duration: 0.5 }}
                  >
                    <CheckCircle2 className="w-20 h-20 text-green-500 mx-auto mb-4" />
                  </motion.div>
                  <h2 className="text-2xl font-bold text-green-600 mb-2">Pendaftaran Berhasil!</h2>
                  <p className="text-gray-600 mb-6">
                    Akun Anda telah berhasil dibuat. Silakan login untuk melanjutkan.
                  </p>
                  <Button
                    onClick={() => setCurrentPage('login')}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    <ArrowLeft className="mr-2 w-4 h-4" />
                    Ke Halaman Login
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      );
    }

    return (
      <div className="min-h-screen flex flex-col relative overflow-hidden">
        <div className="absolute inset-0 animate-gradient-red-white opacity-70" />
        
        <div className="relative z-10 flex-1 py-8 px-4 overflow-y-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            className="max-w-2xl mx-auto"
          >
            <Card className="bg-white/95 backdrop-blur-lg shadow-2xl">
              <CardHeader className="text-center">
                <motion.div 
                  initial={{ y: -20 }}
                  animate={{ y: 0 }}
                  className="flex justify-center mb-4"
                >
                  <UserPlus className="w-16 h-16 text-red-600" />
                </motion.div>
                <CardTitle className="text-2xl font-bold text-red-700">{settings.register_title}</CardTitle>
                <CardDescription>{settings.register_subtitle}</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleRegister} className="space-y-6">
                  {error && (
                    <Alert variant="destructive" className="bg-red-50 border-red-200">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}
                  
                  {/* Data Akun */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg text-gray-800 border-b pb-2">Data Akun</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="username">Username *</Label>
                        <Input id="username" type="text" placeholder="Minimal 4 karakter" value={username} onChange={(e) => setUsername(e.target.value)} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email *</Label>
                        <Input id="email" type="email" placeholder="contoh@email.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="password">Password *</Label>
                        <div className="relative">
                          <Input id="password" type={showPassword ? 'text' : 'password'} placeholder="Minimal 6 karakter" value={password} onChange={(e) => setPassword(e.target.value)} required />
                          <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1 h-7 w-7" onClick={() => setShowPassword(!showPassword)}>
                            {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                          </Button>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="confirmPassword">Konfirmasi Password *</Label>
                        <Input id="confirmPassword" type={showPassword ? 'text' : 'password'} placeholder="Ulangi password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
                      </div>
                    </div>
                  </div>
                  
                  {/* Data Diri */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg text-gray-800 border-b pb-2">Data Diri</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2 md:col-span-2">
                        <Label htmlFor="fullName">Nama Lengkap *</Label>
                        <Input id="fullName" type="text" placeholder="Nama lengkap sesuai akta" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="placeOfBirth">Tempat Lahir *</Label>
                        <Input id="placeOfBirth" type="text" placeholder="Kota kelahiran" value={placeOfBirth} onChange={(e) => setPlaceOfBirth(e.target.value)} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="dateOfBirth">Tanggal Lahir *</Label>
                        <Input id="dateOfBirth" type="date" value={dateOfBirth} onChange={(e) => setDateOfBirth(e.target.value)} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="gender">Jenis Kelamin *</Label>
                        <select id="gender" value={gender} onChange={(e) => setGender(e.target.value)} className="w-full p-2 border rounded-md" required>
                          <option value="">Pilih</option>
                          <option value="Laki-laki">Laki-laki</option>
                          <option value="Perempuan">Perempuan</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="religion">Agama *</Label>
                        <select id="religion" value={religion} onChange={(e) => setReligion(e.target.value)} className="w-full p-2 border rounded-md" required>
                          <option value="">Pilih</option>
                          <option value="Islam">Islam</option>
                          <option value="Kristen">Kristen</option>
                          <option value="Katolik">Katolik</option>
                          <option value="Hindu">Hindu</option>
                          <option value="Buddha">Buddha</option>
                          <option value="Konghucu">Konghucu</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  {/* Data Fisik */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg text-gray-800 border-b pb-2">Data Fisik</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="height">Tinggi Badan (cm) *</Label>
                        <Input id="height" type="number" placeholder="contoh: 165" value={height} onChange={(e) => setHeight(e.target.value)} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="weight">Berat Badan (kg) *</Label>
                        <Input id="weight" type="number" placeholder="contoh: 55" value={weight} onChange={(e) => setWeight(e.target.value)} required />
                      </div>
                    </div>
                  </div>
                  
                  {/* Data Sekolah */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg text-gray-800 border-b pb-2">Data Sekolah</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="school">Asal Sekolah *</Label>
                        <Input id="school" type="text" placeholder="Nama sekolah" value={school} onChange={(e) => setSchool(e.target.value)} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="classGrade">Kelas *</Label>
                        <select id="classGrade" value={classGrade} onChange={(e) => setClassGrade(e.target.value)} className="w-full p-2 border rounded-md" required>
                          <option value="">Pilih</option>
                          <option value="X">X (Sepuluh)</option>
                          <option value="XI">XI (Sebelas)</option>
                          <option value="XII">XII (Dua belas)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  {/* Data Kontak */}
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg text-gray-800 border-b pb-2">Data Kontak</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="phone">Nomor Telepon *</Label>
                        <Input id="phone" type="tel" placeholder="08xxxxxxxxxx" value={phone} onChange={(e) => setPhone(e.target.value)} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="address">Alamat Lengkap *</Label>
                        <Input id="address" type="text" placeholder="Alamat lengkap" value={address} onChange={(e) => setAddress(e.target.value)} required />
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={() => setCurrentPage('landing')} className="flex-1">
                      <ArrowLeft className="mr-2 w-4 h-4" />
                      Kembali
                    </Button>
                    <Button type="submit" className="flex-1 bg-red-600 hover:bg-red-700" disabled={loading}>
                      {loading ? 'Memproses...' : (<><Send className="mr-2 w-4 h-4" />Daftar</>)}
                    </Button>
                  </div>
                  
                  <div className="text-center">
                    <p className="text-gray-600 text-sm">
                      Sudah punya akun?{' '}
                      <Button type="button" variant="link" className="p-0 h-auto text-red-600 hover:text-red-700 font-medium" onClick={() => setCurrentPage('login')}>
                        Login di sini
                      </Button>
                    </p>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  };

  // Dashboard Page Component
  const DashboardPage = () => {
    const [quizResult, setQuizResult] = useState<QuizResult | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
      const fetchQuizResult = async () => {
        if (!currentUser) return;
        try {
          const res = await fetch(`/api/quiz/result?participantId=${currentUser.id}`);
          if (res.ok) {
            const data = await res.json();
            setQuizResult(data);
          }
        } catch (error) {
          console.error('Failed to fetch quiz result');
        } finally {
          setLoading(false);
        }
      };
      fetchQuizResult();
    }, [currentUser]);

    if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600" />
        </div>
      );
    }

    const passingScore = parseInt(settings.quiz_passing_score) || 70;
    const passed = quizResult && quizResult.score >= passingScore;

    return (
      <div className="min-h-screen flex flex-col relative overflow-hidden">
        <div className="absolute inset-0 animate-gradient-red-white opacity-70" />
        
        <div className="relative z-10 flex-1 flex items-center justify-center p-3 md:p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-full max-w-2xl"
          >
            <Card className="bg-white/95 backdrop-blur-lg shadow-2xl">
              <CardHeader className="text-center p-4 md:p-6">
                <motion.div initial={{ y: -20 }} animate={{ y: 0 }} className="flex justify-center mb-4">
                  <PaskibrakaLogo size={64} />
                </motion.div>
                <CardTitle className="text-lg md:text-2xl font-bold text-red-700">
                  Selamat Datang, {currentUser?.fullName}!
                </CardTitle>
                <CardDescription className="text-sm">Dashboard Peserta Seleksi Paskibraka</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 md:space-y-6 p-4 md:p-6 pt-0">
                {/* User Info */}
                <div className="grid grid-cols-2 gap-2 md:gap-4 p-3 md:p-4 bg-gray-50 rounded-lg text-sm md:text-base">
                  <div>
                    <p className="text-xs md:text-sm text-gray-500">Nama</p>
                    <p className="font-semibold truncate">{currentUser?.fullName}</p>
                  </div>
                  <div>
                    <p className="text-xs md:text-sm text-gray-500">Sekolah</p>
                    <p className="font-semibold truncate">{currentUser?.school}</p>
                  </div>
                  <div>
                    <p className="text-xs md:text-sm text-gray-500">Kelas</p>
                    <p className="font-semibold">{currentUser?.class}</p>
                  </div>
                  <div>
                    <p className="text-xs md:text-sm text-gray-500">Status</p>
                    <Badge className={`${currentUser?.status === 'approved' ? 'bg-green-500' : currentUser?.status === 'rejected' ? 'bg-red-500' : 'bg-yellow-500'} text-xs`}>
                      {currentUser?.status === 'approved' ? 'Disetujui' : currentUser?.status === 'rejected' ? 'Ditolak' : 'Pending'}
                    </Badge>
                  </div>
                </div>

                {/* Quiz Status */}
                {quizResult ? (
                  <div className={`p-4 md:p-6 rounded-lg ${passed ? 'bg-green-50 border-2 border-green-200' : 'bg-red-50 border-2 border-red-200'}`}>
                    <div className="text-center">
                      {passed ? (
                        <Trophy className="w-12 h-12 md:w-16 md:h-16 text-green-500 mx-auto mb-4" />
                      ) : (
                        <AlertCircle className="w-12 h-12 md:w-16 md:h-16 text-red-500 mx-auto mb-4" />
                      )}
                      <h3 className="text-base md:text-xl font-bold mb-2">
                        {passed ? 'Selamat! Anda Lulus!' : 'Maaf, Anda Belum Lulus'}
                      </h3>
                      <div className="grid grid-cols-3 gap-2 md:gap-4 mt-4">
                        <div className="text-center">
                          <p className="text-xl md:text-3xl font-bold text-red-600">{quizResult.score}%</p>
                          <p className="text-xs md:text-sm text-gray-500">Nilai</p>
                        </div>
                        <div className="text-center">
                          <p className="text-xl md:text-3xl font-bold text-green-600">{quizResult.correctAnswers}/{quizResult.totalQuestions}</p>
                          <p className="text-xs md:text-sm text-gray-500">Benar</p>
                        </div>
                        <div className="text-center">
                          <p className="text-xl md:text-3xl font-bold text-blue-600">{Math.floor(quizResult.timeSpent / 60)}:{(quizResult.timeSpent % 60).toString().padStart(2, '0')}</p>
                          <p className="text-xs md:text-sm text-gray-500">Waktu</p>
                        </div>
                      </div>
                      <p className="text-xs md:text-sm text-gray-500 mt-4">
                        Nilai minimal lulus: {passingScore}%
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-4 md:p-6 bg-blue-50 rounded-lg border-2 border-blue-200">
                    <ClipboardList className="w-12 h-12 md:w-16 md:h-16 text-blue-500 mx-auto mb-4" />
                    <h3 className="text-base md:text-xl font-bold mb-2">Anda Belum Mengerjakan Ujian</h3>
                    <p className="text-gray-600 text-sm md:text-base mb-4">Klik tombol di bawah untuk memulai ujian seleksi</p>
                    <Button onClick={() => setCurrentPage('quiz')} className="bg-red-600 hover:bg-red-700 text-sm md:text-base">
                      <Play className="mr-2 w-4 h-4" />
                      Mulai Ujian
                    </Button>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button variant="outline" onClick={() => { setCurrentUser(null); setCurrentPage('landing'); }} className="flex-1 text-sm">
                    <LogOut className="mr-2 w-4 h-4" />
                    Keluar
                  </Button>
                  {!quizResult && (
                    <Button onClick={() => setCurrentPage('quiz')} className="flex-1 bg-red-600 hover:bg-red-700 text-sm">
                      <Play className="mr-2 w-4 h-4" />
                      Mulai Ujian
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  };

  // Quiz Page Component
  const QuizPage = () => {
    const [questions, setQuestions] = useState<Question[]>([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [answers, setAnswers] = useState<Record<string, string>>({});
    const [timeLeft, setTimeLeft] = useState(parseInt(settings.quiz_duration) * 60);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [started, setStarted] = useState(false);
    const [quizResult, setQuizResult] = useState<QuizResult | null>(null);

    useEffect(() => {
      const fetchQuestions = async () => {
        try {
          const res = await fetch('/api/quiz/questions');
          if (res.ok) {
            const data = await res.json();
            setQuestions(data);
          }
        } catch (error) {
          console.error('Failed to fetch questions');
        } finally {
          setLoading(false);
        }
      };
      fetchQuestions();
    }, []);

    useEffect(() => {
      if (!started || timeLeft <= 0 || submitting) return;
      
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            handleSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(timer);
    }, [started]);

    const handleAnswer = (questionId: string, answer: string) => {
      setAnswers((prev) => ({ ...prev, [questionId]: answer }));
    };

    const handleSubmit = async () => {
      if (submitting || !currentUser) return;
      setSubmitting(true);

      const timeSpent = parseInt(settings.quiz_duration) * 60 - timeLeft;
      const answersArray = Object.entries(answers).map(([questionId, answer]) => ({
        questionId,
        answer,
      }));

      try {
        const res = await fetch('/api/quiz/submit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            participantId: currentUser.id,
            answers: answersArray,
            timeSpent,
          }),
        });

        if (res.ok) {
          const data = await res.json();
          setQuizResult(data.result);
        } else {
          toast.error('Gagal menyimpan hasil ujian');
        }
      } catch (error) {
        toast.error('Terjadi kesalahan');
      }
    };

    const formatTime = (seconds: number) => {
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    };

    if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600" />
        </div>
      );
    }

    if (questions.length === 0) {
      return (
        <div className="min-h-screen flex flex-col relative overflow-hidden">
          <div className="absolute inset-0 animate-gradient-red-white opacity-70" />
          <div className="relative z-10 flex-1 flex items-center justify-center p-6">
            <Card className="w-full max-w-md bg-white/95 backdrop-blur-lg shadow-2xl">
              <CardContent className="pt-8 pb-8 text-center">
                <AlertCircle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
                <h2 className="text-xl font-bold mb-2">Belum Ada Soal</h2>
                <p className="text-gray-600 mb-4">Admin belum menambahkan soal ujian</p>
                <Button onClick={() => setCurrentPage('dashboard')} variant="outline">
                  <ArrowLeft className="mr-2 w-4 h-4" />
                  Kembali
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      );
    }

    // Show result
    if (quizResult) {
      const passingScore = parseInt(settings.quiz_passing_score) || 70;
      const passed = quizResult.score >= passingScore;

      return (
        <div className="min-h-screen flex flex-col relative overflow-hidden">
          <div className="absolute inset-0 animate-gradient-red-white opacity-70" />
          <div className="relative z-10 flex-1 flex items-center justify-center p-6">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="w-full max-w-lg"
            >
              <Card className="bg-white/95 backdrop-blur-lg shadow-2xl">
                <CardContent className="pt-8 pb-8 text-center">
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', duration: 0.5 }}
                  >
                    {passed ? (
                      <Trophy className="w-24 h-24 text-green-500 mx-auto mb-4" />
                    ) : (
                      <AlertCircle className="w-24 h-24 text-red-500 mx-auto mb-4" />
                    )}
                  </motion.div>
                  <h2 className={`text-2xl font-bold mb-2 ${passed ? 'text-green-600' : 'text-red-600'}`}>
                    {passed ? 'Selamat! Anda Lulus!' : 'Maaf, Anda Belum Lulus'}
                  </h2>
                  <p className="text-gray-600 mb-6">Ujian telah selesai</p>
                  
                  <div className="grid grid-cols-3 gap-4 mb-6">
                    <div className="p-4 bg-red-50 rounded-lg">
                      <p className="text-3xl font-bold text-red-600">{quizResult.score}%</p>
                      <p className="text-sm text-gray-500">Nilai</p>
                    </div>
                    <div className="p-4 bg-green-50 rounded-lg">
                      <p className="text-3xl font-bold text-green-600">{quizResult.correctAnswers}/{quizResult.totalQuestions}</p>
                      <p className="text-sm text-gray-500">Benar</p>
                    </div>
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <p className="text-3xl font-bold text-blue-600">{Math.floor(quizResult.timeSpent / 60)}:{(quizResult.timeSpent % 60).toString().padStart(2, '0')}</p>
                      <p className="text-sm text-gray-500">Waktu</p>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-500 mb-6">
                    Nilai minimal lulus: {passingScore}%
                  </p>
                  
                  <Button onClick={() => setCurrentPage('dashboard')} className="bg-red-600 hover:bg-red-700">
                    Lihat Dashboard
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      );
    }

    // Start screen
    if (!started) {
      return (
        <div className="min-h-screen flex flex-col relative overflow-hidden">
          <div className="absolute inset-0 animate-gradient-red-white opacity-70" />
          <div className="relative z-10 flex-1 flex items-center justify-center p-3 md:p-6">
            <Card className="w-full max-w-lg bg-white/95 backdrop-blur-lg shadow-2xl">
              <CardHeader className="text-center">
                <CardTitle className="text-lg md:text-2xl font-bold text-red-700">{settings.quiz_title}</CardTitle>
                <CardDescription className="text-sm">Persiapan Ujian Seleksi Paskibraka</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-3 md:gap-4 p-3 md:p-4 bg-gray-50 rounded-lg">
                  <div className="text-center">
                    <Clock className="w-6 h-6 md:w-8 md:h-8 text-blue-500 mx-auto mb-2" />
                    <p className="text-xl md:text-2xl font-bold">{settings.quiz_duration}</p>
                    <p className="text-xs md:text-sm text-gray-500">Menit</p>
                  </div>
                  <div className="text-center">
                    <FileQuestion className="w-6 h-6 md:w-8 md:h-8 text-green-500 mx-auto mb-2" />
                    <p className="text-xl md:text-2xl font-bold">{questions.length}</p>
                    <p className="text-xs md:text-sm text-gray-500">Soal</p>
                  </div>
                </div>
                
                <div className="p-3 md:p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <h4 className="font-semibold text-yellow-700 mb-2 text-sm md:text-base">Peraturan Ujian:</h4>
                  <ul className="text-xs md:text-sm text-yellow-600 space-y-1">
                    <li>• Jawaban tidak dapat diubah setelah dikirim</li>
                    <li>• Soal akan otomatis dikirim saat waktu habis</li>
                    <li>• Nilai minimal lulus: {settings.quiz_passing_score}%</li>
                    <li>• Pastikan koneksi internet stabil</li>
                  </ul>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button variant="outline" onClick={() => setCurrentPage('dashboard')} className="flex-1 text-sm">
                    <ArrowLeft className="mr-2 w-4 h-4" />
                    Kembali
                  </Button>
                  <Button onClick={() => setStarted(true)} className="flex-1 bg-red-600 hover:bg-red-700 text-sm">
                    <Play className="mr-2 w-4 h-4" />
                    Mulai Ujian
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      );
    }

    // Quiz screen
    const currentQuestion = questions[currentIndex];
    const progress = ((currentIndex + 1) / questions.length) * 100;

    return (
      <div className="min-h-screen flex flex-col bg-gray-50">
        {/* Header */}
        <header className="bg-red-600 text-white shadow-lg sticky top-0 z-10">
          <div className="container mx-auto px-2 md:px-4 py-2 md:py-3 flex items-center justify-between">
            <h1 className="text-sm md:text-lg font-bold truncate max-w-[120px] md:max-w-none">{settings.quiz_title}</h1>
            <div className={`flex items-center gap-1 md:gap-2 px-2 md:px-4 py-1 md:py-2 rounded-lg ${timeLeft < 300 ? 'bg-red-500 animate-pulse' : 'bg-white/20'}`}>
              <Clock className="w-4 h-4 md:w-5 md:h-5" />
              <span className="text-lg md:text-xl font-bold font-mono">{formatTime(timeLeft)}</span>
            </div>
          </div>
          {/* Progress bar */}
          <div className="h-1 bg-white/20">
            <div className="h-full bg-white transition-all" style={{ width: `${progress}%` }} />
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 container mx-auto px-2 md:px-4 py-4 md:py-6 max-w-3xl">
          <Card className="shadow-lg">
            <CardHeader className="p-4 md:p-6">
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="text-xs md:text-lg px-2 md:px-3 py-0.5 md:py-1">
                  Soal {currentIndex + 1}/{questions.length}
                </Badge>
              </div>
              <CardTitle className="text-base md:text-xl mt-3 md:mt-4">{currentQuestion.question}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 px-4 md:px-6">
              {(['A', 'B', 'C', 'D'] as const).map((opt) => {
                const optionKey = `option${opt}` as keyof Question;
                const optionText = currentQuestion[optionKey] as string;
                const isSelected = answers[currentQuestion.id] === opt;
                
                return (
                  <button
                    key={opt}
                    onClick={() => handleAnswer(currentQuestion.id, opt)}
                    className={`w-full p-3 md:p-4 text-left rounded-lg border-2 transition-all text-sm md:text-base ${
                      isSelected 
                        ? 'border-red-500 bg-red-50 text-red-700' 
                        : 'border-gray-200 hover:border-red-300 hover:bg-gray-50'
                    }`}
                  >
                    <span className={`inline-flex items-center justify-center w-6 h-6 md:w-8 md:h-8 rounded-full mr-2 md:mr-3 font-bold text-xs md:text-sm ${
                      isSelected ? 'bg-red-500 text-white' : 'bg-gray-200'
                    }`}>
                      {opt}
                    </span>
                    {optionText}
                  </button>
                );
              })}
            </CardContent>
          </Card>

          {/* Navigation */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mt-6">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentIndex((prev) => Math.max(0, prev - 1))}
              disabled={currentIndex === 0}
              className="w-full sm:w-auto"
            >
              <ArrowLeft className="mr-2 w-4 h-4" />
              Sebelumnya
            </Button>
            
            <div className="flex gap-1 md:gap-2 overflow-x-auto max-w-full py-2 px-1">
              {questions.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`w-7 h-7 md:w-8 md:h-8 rounded-full text-xs md:text-sm font-medium transition-all flex-shrink-0 ${
                    idx === currentIndex
                      ? 'bg-red-600 text-white'
                      : answers[questions[idx].id]
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-200'
                  }`}
                >
                  {idx + 1}
                </button>
              ))}
            </div>
            
            {currentIndex === questions.length - 1 ? (
              <Button onClick={handleSubmit} disabled={submitting} size="sm" className="w-full sm:w-auto bg-green-600 hover:bg-green-700">
                <Send className="mr-2 w-4 h-4" />
                {submitting ? 'Mengirim...' : 'Selesai'}
              </Button>
            ) : (
              <Button onClick={() => setCurrentIndex((prev) => Math.min(questions.length - 1, prev + 1))} size="sm" className="w-full sm:w-auto bg-red-600 hover:bg-red-700">
                Selanjutnya
                <ChevronRight className="ml-2 w-4 h-4" />
              </Button>
            )}
          </div>
        </main>
      </div>
    );
  };

  // Admin Login Component
  const AdminLoginPage = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleLogin = async (e: React.FormEvent) => {
      e.preventDefault();
      setError('');
      setLoading(true);

      try {
        const res = await fetch('/api/admin/auth', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username, password }),
        });

        const data = await res.json();

        if (res.ok) {
          setCurrentPage('admin');
        } else {
          setError(data.error || 'Username atau password salah');
        }
      } catch {
        setError('Terjadi kesalahan. Silakan coba lagi.');
      } finally {
        setLoading(false);
      }
    };

    return (
      <div className="min-h-screen flex flex-col relative overflow-hidden">
        <div className="absolute inset-0 animate-gradient-red-white opacity-70" />
        
        <div className="relative z-10 flex-1 flex items-center justify-center p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="w-full max-w-md bg-white/95 backdrop-blur-lg shadow-2xl">
              <CardHeader className="text-center">
                <motion.div initial={{ y: -20 }} animate={{ y: 0 }} className="flex justify-center mb-4">
                  <Settings className="w-16 h-16 text-red-600" />
                </motion.div>
                <CardTitle className="text-2xl font-bold text-red-700">Admin Login</CardTitle>
                <CardDescription>Masuk ke panel administrator</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleLogin} className="space-y-4">
                  {error && (
                    <Alert variant="destructive" className="bg-red-50 border-red-200">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="space-y-2">
                    <Label htmlFor="admin-username">Username</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                      <Input id="admin-username" type="text" placeholder="Username admin" value={username} onChange={(e) => setUsername(e.target.value)} className="pl-10" required />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="admin-password">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                      <Input id="admin-password" type="password" placeholder="Password admin" value={password} onChange={(e) => setPassword(e.target.value)} className="pl-10" required />
                    </div>
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <Button type="button" variant="outline" onClick={() => setCurrentPage('landing')} className="flex-1">
                      <ArrowLeft className="mr-2 w-4 h-4" />
                      Kembali
                    </Button>
                    <Button type="submit" className="flex-1 bg-red-600 hover:bg-red-700" disabled={loading}>
                      {loading ? 'Memproses...' : 'Masuk'}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    );
  };

  // Admin Panel Component
  const AdminPanel = () => {
    const [activeTab, setActiveTab] = useState('participants');
    const [participants, setParticipants] = useState<Participant[]>([]);
    const [questions, setQuestions] = useState<Question[]>([]);
    const [songs, setSongs] = useState<Song[]>([]);
    const [adminAnnouncements, setAdminAnnouncements] = useState<Announcement[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
      fetchData();
    }, []);

    const fetchData = async () => {
      try {
        const [participantsRes, questionsRes, songsRes, announcementsRes] = await Promise.all([
          fetch('/api/admin/participants'),
          fetch('/api/admin/questions'),
          fetch('/api/admin/songs'),
          fetch('/api/admin/announcements'),
        ]);

        if (participantsRes.ok) {
          const data = await participantsRes.json();
          setParticipants(data);
        }
        if (questionsRes.ok) {
          const data = await questionsRes.json();
          setQuestions(data);
        }
        if (songsRes.ok) {
          const data = await songsRes.json();
          setSongs(data);
        }
        if (announcementsRes.ok) {
          const data = await announcementsRes.json();
          setAdminAnnouncements(data);
        }
      } catch (error) {
        toast.error('Gagal memuat data');
      } finally {
        setLoading(false);
      }
    };

    const exportCSV = () => {
      const headers = ['Nama Lengkap', 'Username', 'Email', 'Tempat Lahir', 'Tanggal Lahir', 'Jenis Kelamin', 'Agama', 'Tinggi (cm)', 'Berat (kg)', 'Sekolah', 'Kelas', 'No. Telepon', 'Alamat', 'Nilai Ujian', 'Jawaban Benar', 'Total Soal', 'Waktu (menit)', 'Status', 'Tanggal Daftar'];
      const rows = participants.map(p => [
        p.fullName, p.username, p.email, p.placeOfBirth, p.dateOfBirth,
        p.gender, p.religion, p.height, p.weight, p.school, p.class,
        p.phone, p.address, 
        p.quizScore !== null ? `${p.quizScore}%` : 'Belum ujian',
        p.quizCorrectAnswers !== null ? p.quizCorrectAnswers : '-',
        p.quizTotalQuestions !== null ? p.quizTotalQuestions : '-',
        p.quizTimeSpent !== null ? `${Math.floor(p.quizTimeSpent / 60)}:${(p.quizTimeSpent % 60).toString().padStart(2, '0')}` : '-',
        p.status, 
        new Date(p.createdAt).toLocaleDateString('id-ID'),
      ]);
      const csvContent = [headers.join(','), ...rows.map(row => row.map(cell => `"${cell || ''}"`).join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `peserta-paskibraka-${new Date().toISOString().split('T')[0]}.csv`;
      link.click();
      toast.success('Data berhasil diunduh');
    };

    const updateParticipantStatus = async (id: string, status: string) => {
      try {
        const res = await fetch(`/api/admin/participants/${id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status }),
        });
        if (res.ok) {
          toast.success('Status berhasil diperbarui');
          fetchData();
        }
      } catch {
        toast.error('Gagal memperbarui status');
      }
    };

    const deleteParticipant = async (id: string, name: string) => {
      if (!confirm(`Yakin ingin menghapus akun "${name}"? Tindakan ini tidak dapat dibatalkan.`)) return;
      try {
        const res = await fetch(`/api/admin/participants/${id}`, { method: 'DELETE' });
        if (res.ok) {
          toast.success('Akun peserta berhasil dihapus');
          fetchData();
        } else {
          const data = await res.json();
          toast.error(data.error || 'Gagal menghapus akun');
        }
      } catch {
        toast.error('Gagal menghapus akun');
      }
    };

    const deleteQuestion = async (id: string) => {
      if (!confirm('Yakin ingin menghapus soal ini?')) return;
      try {
        const res = await fetch(`/api/admin/questions/${id}`, { method: 'DELETE' });
        if (res.ok) {
          toast.success('Soal berhasil dihapus');
          fetchData();
        }
      } catch {
        toast.error('Gagal menghapus soal');
      }
    };

    // Add Question Form
    const AddQuestionForm = () => {
      const [question, setQuestion] = useState('');
      const [optionA, setOptionA] = useState('');
      const [optionB, setOptionB] = useState('');
      const [optionC, setOptionC] = useState('');
      const [optionD, setOptionD] = useState('');
      const [answer, setAnswer] = useState('A');
      const [submitting, setSubmitting] = useState(false);

      const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
          const res = await fetch('/api/admin/questions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ question, optionA, optionB, optionC, optionD, answer }),
          });
          if (res.ok) {
            toast.success('Soal berhasil ditambahkan');
            setQuestion(''); setOptionA(''); setOptionB(''); setOptionC(''); setOptionD(''); setAnswer('A');
            fetchData();
          }
        } catch {
          toast.error('Gagal menambahkan soal');
        } finally {
          setSubmitting(false);
        }
      };

      return (
        <Card className="mb-6">
          <CardHeader><CardTitle className="text-lg">Tambah Soal Baru</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Pertanyaan</Label>
                <Input value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="Tulis pertanyaan..." required />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Opsi A</Label><Input value={optionA} onChange={(e) => setOptionA(e.target.value)} required /></div>
                <div className="space-y-2"><Label>Opsi B</Label><Input value={optionB} onChange={(e) => setOptionB(e.target.value)} required /></div>
                <div className="space-y-2"><Label>Opsi C</Label><Input value={optionC} onChange={(e) => setOptionC(e.target.value)} required /></div>
                <div className="space-y-2"><Label>Opsi D</Label><Input value={optionD} onChange={(e) => setOptionD(e.target.value)} required /></div>
              </div>
              <div className="space-y-2">
                <Label>Jawaban Benar</Label>
                <select value={answer} onChange={(e) => setAnswer(e.target.value)} className="w-full p-2 border rounded">
                  <option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option>
                </select>
              </div>
              <Button type="submit" disabled={submitting} className="bg-red-600 hover:bg-red-700">
                <Plus className="mr-2 w-4 h-4" />Tambah Soal
              </Button>
            </form>
          </CardContent>
        </Card>
      );
    };

    // Add Song Form
    const AddSongForm = () => {
      const [title, setTitle] = useState('');
      const [audioUrl, setAudioUrl] = useState('');
      const [submitting, setSubmitting] = useState(false);

      const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
          const res = await fetch('/api/admin/songs', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, audioUrl }),
          });
          if (res.ok) {
            toast.success('Lagu berhasil ditambahkan');
            setTitle(''); setAudioUrl('');
            fetchData();
          }
        } catch {
          toast.error('Gagal menambahkan lagu');
        } finally {
          setSubmitting(false);
        }
      };

      return (
        <Card className="mb-6">
          <CardHeader><CardTitle className="text-lg">Tambah Lagu Nasional</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2"><Label>Judul Lagu</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Judul lagu..." required /></div>
              <div className="space-y-2"><Label>URL Audio</Label><Input value={audioUrl} onChange={(e) => setAudioUrl(e.target.value)} placeholder="https://example.com/song.mp3" required /></div>
              <Button type="submit" disabled={submitting} className="bg-red-600 hover:bg-red-700"><Music className="mr-2 w-4 h-4" />Tambah Lagu</Button>
            </form>
          </CardContent>
        </Card>
      );
    };

    // Add Announcement Form
    const AddAnnouncementForm = () => {
      const [title, setTitle] = useState('');
      const [content, setContent] = useState('');
      const [submitting, setSubmitting] = useState(false);

      const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
          const res = await fetch('/api/admin/announcements', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, content, isActive: true }),
          });
          if (res.ok) {
            toast.success('Pengumuman berhasil ditambahkan');
            setTitle(''); setContent('');
            fetchData();
          }
        } catch {
          toast.error('Gagal menambahkan pengumuman');
        } finally {
          setSubmitting(false);
        }
      };

      return (
        <Card className="mb-6">
          <CardHeader><CardTitle className="text-lg">Tambah Pengumuman</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2"><Label>Judul</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Judul pengumuman..." required /></div>
              <div className="space-y-2"><Label>Isi Pengumuman</Label><Textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="Tulis pengumuman..." required rows={3} /></div>
              <Button type="submit" disabled={submitting} className="bg-red-600 hover:bg-red-700"><Megaphone className="mr-2 w-4 h-4" />Tambah Pengumuman</Button>
            </form>
          </CardContent>
        </Card>
      );
    };

    // Settings Form
    const SettingsForm = () => {
      const [localSettings, setLocalSettings] = useState<AppSettings>(settings);
      const [saving, setSaving] = useState(false);

      const settingGroups = [
        { title: 'Halaman Utama', settings: [
          { key: 'site_title', label: 'Judul Website', description: 'Judul utama yang ditampilkan di halaman landing' },
          { key: 'site_subtitle', label: 'Subjudul Website', description: 'Subjudul di bawah judul utama' },
          { key: 'badge_merah', label: 'Teks Badge Merah', description: 'Teks pada badge warna merah' },
          { key: 'badge_putih', label: 'Teks Badge Putih', description: 'Teks pada badge warna putih' },
          { key: 'button_masuk', label: 'Teks Tombol Masuk', description: 'Label tombol masuk' },
          { key: 'button_buat_akun', label: 'Teks Tombol Buat Akun', description: 'Label tombol buat akun' },
          { key: 'button_admin', label: 'Teks Tombol Admin', description: 'Label tombol admin' },
          { key: 'footer_text', label: 'Teks Footer', description: 'Teks yang ditampilkan di footer' },
        ]},
        { title: 'Halaman Login', settings: [
          { key: 'login_title', label: 'Judul Login', description: 'Judul halaman login peserta' },
          { key: 'login_subtitle', label: 'Subjudul Login', description: 'Deskripsi di bawah judul login' },
        ]},
        { title: 'Halaman Registrasi', settings: [
          { key: 'register_title', label: 'Judul Registrasi', description: 'Judul halaman pendaftaran' },
          { key: 'register_subtitle', label: 'Subjudul Registrasi', description: 'Deskripsi di bawah judul pendaftaran' },
        ]},
        { title: 'Admin Panel', settings: [
          { key: 'admin_title', label: 'Judul Admin Panel', description: 'Judul header admin panel' },
        ]},
        { title: 'Pengaturan Ujian', settings: [
          { key: 'quiz_title', label: 'Judul Ujian', description: 'Judul halaman ujian' },
          { key: 'quiz_duration', label: 'Durasi Ujian (menit)', description: 'Waktu pengerjaan ujian dalam menit' },
          { key: 'quiz_passing_score', label: 'Nilai Minimal Lulus (%)', description: 'Nilai minimum untuk lulus ujian' },
        ]},
      ];

      const handleSave = async () => {
        setSaving(true);
        try {
          for (const [key, value] of Object.entries(localSettings)) {
            await fetch('/api/admin/settings', {
              method: 'PUT',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ key, value }),
            });
          }
          setSettings(localSettings);
          toast.success('Pengaturan berhasil disimpan');
        } catch (error) {
          toast.error('Gagal menyimpan pengaturan');
        } finally {
          setSaving(false);
        }
      };

      const handleReset = () => {
        const defaults = {
          site_title: 'Seleksi Paskibraka',
          site_subtitle: 'Panji-Panji Garuda Indonesia',
          badge_merah: 'Merah',
          badge_putih: 'Putih',
          button_masuk: 'Masuk',
          button_buat_akun: 'Buat Akun',
          button_admin: 'Admin Panel',
          footer_text: '© 2024 Seleksi Paskibraka - Panji-Panji Garuda Indonesia',
          login_title: 'Login Peserta',
          login_subtitle: 'Masukkan kredensial akun Anda',
          register_title: 'Pendaftaran Peserta',
          register_subtitle: 'Lengkapi data diri Anda untuk mendaftar seleksi Paskibraka',
          admin_title: 'Admin Panel - Paskibraka',
          quiz_duration: '30',
          quiz_passing_score: '70',
          quiz_title: 'Ujian Seleksi Paskibraka',
        };
        setLocalSettings(defaults);
        toast.info('Pengaturan direset ke default');
      };

      return (
        <div className="space-y-6">
          {settingGroups.map((group) => (
            <Card key={group.title}>
              <CardHeader><CardTitle className="text-lg">{group.title}</CardTitle></CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {group.settings.map((setting) => (
                    <div key={setting.key} className="space-y-2">
                      <Label htmlFor={setting.key}>{setting.label}</Label>
                      <Input id={setting.key} value={localSettings[setting.key] || ''} onChange={(e) => setLocalSettings(prev => ({ ...prev, [setting.key]: e.target.value }))} placeholder={setting.description} />
                      <p className="text-xs text-gray-500">{setting.description}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
          <div className="flex gap-3 justify-end">
            <Button variant="outline" onClick={handleReset}>Reset ke Default</Button>
            <Button onClick={handleSave} disabled={saving} className="bg-red-600 hover:bg-red-700">{saving ? 'Menyimpan...' : 'Simpan Pengaturan'}</Button>
          </div>
        </div>
      );
    };

    // Credentials Form
    const CredentialsForm = () => {
      const [currentUsername, setCurrentUsername] = useState('');
      const [currentPassword, setCurrentPassword] = useState('');
      const [newUsername, setNewUsername] = useState('');
      const [newPassword, setNewPassword] = useState('');
      const [showCurrentPassword, setShowCurrentPassword] = useState(false);
      const [showNewPassword, setShowNewPassword] = useState(false);
      const [loading, setLoading] = useState(false);
      const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

      useEffect(() => {
        fetchCredentials();
      }, []);

      const fetchCredentials = async () => {
        try {
          const res = await fetch('/api/admin/credentials');
          if (res.ok) {
            const data = await res.json();
            setCurrentUsername(data.username);
          }
        } catch {
          console.error('Failed to fetch credentials');
        }
      };

      const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setMessage(null);

        if (!currentPassword) {
          setMessage({ type: 'error', text: 'Password saat ini harus diisi' });
          return;
        }

        if (!newUsername && !newPassword) {
          setMessage({ type: 'error', text: 'Masukkan username baru atau password baru' });
          return;
        }

        if (newUsername && newUsername.length < 4) {
          setMessage({ type: 'error', text: 'Username baru minimal 4 karakter' });
          return;
        }

        if (newPassword && newPassword.length < 6) {
          setMessage({ type: 'error', text: 'Password baru minimal 6 karakter' });
          return;
        }

        setLoading(true);

        try {
          const res = await fetch('/api/admin/credentials', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              currentPassword,
              newUsername: newUsername || null,
              newPassword: newPassword || null,
            }),
          });

          const data = await res.json();

          if (res.ok) {
            setMessage({ type: 'success', text: data.message + '. Anda akan logout otomatis...' });
            setTimeout(() => {
              setCurrentPage('landing');
            }, 2000);
          } else {
            setMessage({ type: 'error', text: data.error });
          }
        } catch {
          setMessage({ type: 'error', text: 'Terjadi kesalahan. Silakan coba lagi.' });
        } finally {
          setLoading(false);
        }
      };

      return (
        <div>
          <h2 className="text-lg md:text-2xl font-bold mb-2">Pengaturan Keamanan</h2>
          <p className="text-gray-500 text-sm mb-4 md:mb-6">Ubah username dan password admin</p>

          <Card className="max-w-lg">
            <CardContent className="p-4 md:p-6">
              {message && (
                <Alert className={`mb-4 ${message.type === 'success' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                  <AlertCircle className={`h-4 w-4 ${message.type === 'success' ? 'text-green-600' : 'text-red-600'}`} />
                  <AlertDescription className={message.type === 'success' ? 'text-green-600' : 'text-red-600'}>
                    {message.text}
                  </AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center gap-2 text-blue-700">
                    <AlertCircle className="w-4 h-4" />
                    <span className="font-medium">Username saat ini: <strong>{currentUsername}</strong></span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Password Saat Ini *</Label>
                  <div className="relative">
                    <Input
                      type={showCurrentPassword ? 'text' : 'password'}
                      placeholder="Masukkan password saat ini"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-1 top-1 h-7 w-7"
                      onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                    >
                      {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                <div className="border-t pt-4 mt-4">
                  <h4 className="font-medium text-gray-700 mb-3">Ubah Kredensial (opsional)</h4>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Username Baru</Label>
                      <Input
                        type="text"
                        placeholder="Masukkan username baru (kosongkan jika tidak diubah)"
                        value={newUsername}
                        onChange={(e) => setNewUsername(e.target.value)}
                      />
                      <p className="text-xs text-gray-500">Minimal 4 karakter</p>
                    </div>

                    <div className="space-y-2">
                      <Label>Password Baru</Label>
                      <div className="relative">
                        <Input
                          type={showNewPassword ? 'text' : 'password'}
                          placeholder="Masukkan password baru (kosongkan jika tidak diubah)"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-1 top-1 h-7 w-7"
                          onClick={() => setShowNewPassword(!showNewPassword)}
                        >
                          {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </Button>
                      </div>
                      <p className="text-xs text-gray-500">Minimal 6 karakter</p>
                    </div>
                  </div>
                </div>

                <Button type="submit" disabled={loading} className="w-full bg-red-600 hover:bg-red-700">
                  {loading ? 'Menyimpan...' : 'Simpan Perubahan'}
                </Button>
              </form>
            </CardContent>
          </Card>

          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mt-6 max-w-lg">
            <h4 className="font-semibold text-yellow-700 mb-2 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Peringatan
            </h4>
            <ul className="text-sm text-yellow-600 space-y-1">
              <li>• Simpan username dan password baru di tempat aman</li>
              <li>• Anda akan logout otomatis setelah mengubah kredensial</li>
              <li>• Gunakan password yang kuat dan tidak mudah ditebak</li>
            </ul>
          </div>
        </div>
      );
    };

    if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600" />
        </div>
      );
    }

    return (
      <div className="min-h-screen flex flex-col bg-gray-50">
        <header className="bg-red-600 text-white shadow-lg">
          <div className="container mx-auto px-2 md:px-4 py-3 md:py-4 flex items-center justify-between">
            <div className="flex items-center gap-2 md:gap-3">
              <PaskibrakaLogo size={32} />
              <h1 className="text-sm md:text-xl font-bold truncate">Admin Panel</h1>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setCurrentPage('landing')} className="text-white hover:bg-red-700 text-xs md:text-sm px-2 md:px-4">
              <LogOut className="mr-1 md:mr-2 w-3 h-3 md:w-4 md:h-4" /><span className="hidden sm:inline">Keluar</span><span className="sm:hidden">Exit</span>
            </Button>
          </div>
        </header>

        <main className="flex-1 container mx-auto px-2 md:px-4 py-4 md:py-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <div className="w-full overflow-x-auto pb-2 -mx-2 px-2 md:mx-0 md:px-0">
              <TabsList className="inline-flex w-max md:w-full md:grid md:grid-cols-6 gap-1 md:gap-0 mb-4 md:mb-6">
                <TabsTrigger value="participants" className="flex items-center gap-1 md:gap-2 text-xs md:text-sm px-2 md:px-4"><Users className="w-3 h-3 md:w-4 md:h-4" /><span className="hidden sm:inline">Peserta</span><span className="sm:hidden">Peserta</span></TabsTrigger>
                <TabsTrigger value="questions" className="flex items-center gap-1 md:gap-2 text-xs md:text-sm px-2 md:px-4"><FileQuestion className="w-3 h-3 md:w-4 md:h-4" /><span className="hidden sm:inline">Soal</span><span className="sm:hidden">Soal</span></TabsTrigger>
                <TabsTrigger value="songs" className="flex items-center gap-1 md:gap-2 text-xs md:text-sm px-2 md:px-4"><Music className="w-3 h-3 md:w-4 md:h-4" /><span className="hidden sm:inline">Lagu</span><span className="sm:hidden">Lagu</span></TabsTrigger>
                <TabsTrigger value="announcements" className="flex items-center gap-1 md:gap-2 text-xs md:text-sm px-2 md:px-4"><Megaphone className="w-3 h-3 md:w-4 md:h-4" /><span className="hidden sm:inline">Pengumuman</span><span className="sm:hidden">Info</span></TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center gap-1 md:gap-2 text-xs md:text-sm px-2 md:px-4"><Settings className="w-3 h-3 md:w-4 md:h-4" /><span className="hidden sm:inline">Pengaturan</span><span className="sm:hidden">Setting</span></TabsTrigger>
                <TabsTrigger value="credentials" className="flex items-center gap-1 md:gap-2 text-xs md:text-sm px-2 md:px-4"><Lock className="w-3 h-3 md:w-4 md:h-4" /><span className="hidden sm:inline">Keamanan</span><span className="sm:hidden">Akun</span></TabsTrigger>
              </TabsList>
            </div>

            {/* Participants Tab */}
            <TabsContent value="participants">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-4 md:mb-6">
                <div>
                  <h2 className="text-lg md:text-2xl font-bold">Daftar Peserta</h2>
                  <p className="text-gray-500 text-sm">Total: {participants.length} peserta</p>
                </div>
                <Button onClick={exportCSV} variant="outline" size="sm" className="flex items-center gap-2 text-xs md:text-sm"><Download className="w-3 h-3 md:w-4 md:h-4" />Export CSV</Button>
              </div>
              
              {/* Mobile Card View - Scrollable */}
              <div className="md:hidden">
                {participants.length === 0 ? (
                  <Card className="p-6 text-center text-gray-500">Belum ada peserta terdaftar</Card>
                ) : (
                  <ScrollArea className="h-[60vh] pr-2">
                    <div className="space-y-3 pb-4">
                      {participants.map((p) => {
                        const passingScore = parseInt(settings.quiz_passing_score) || 70;
                        const isPassed = p.quizScore !== null && p.quizScore >= passingScore;
                        
                        return (
                          <Card key={p.id} className="overflow-hidden">
                            <div className="p-3">
                              <div className="flex justify-between items-start mb-2">
                                <div className="flex-1 min-w-0">
                                  <h3 className="font-semibold text-sm truncate">{p.fullName}</h3>
                                  <p className="text-xs text-gray-500 truncate">{p.email}</p>
                                </div>
                                <Badge className={`${p.status === 'approved' ? 'bg-green-500' : p.status === 'rejected' ? 'bg-red-500' : 'bg-yellow-500'} text-[10px] ml-2 flex-shrink-0`}>
                                  {p.status === 'approved' ? '✓' : p.status === 'rejected' ? '✗' : '⏳'}
                                </Badge>
                              </div>
                              
                              <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs mb-2">
                                <div className="flex justify-between">
                                  <span className="text-gray-400">Sekolah:</span>
                                  <span className="font-medium truncate ml-1">{p.school}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-400">Kelas:</span>
                                  <span className="font-medium">{p.class}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-400">JK:</span>
                                  <span className="font-medium">{p.gender === 'Laki-laki' ? 'L' : 'P'}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-gray-400">TB/BB:</span>
                                  <span className="font-medium">{p.height}/{p.weight}</span>
                                </div>
                              </div>
                              
                              <div className="bg-gray-50 rounded p-2 mb-2">
                                <div className="flex items-center justify-between">
                                  <span className="text-gray-400 text-xs">Nilai:</span>
                                  {p.quizScore !== null ? (
                                    <div className="flex items-center gap-2">
                                      <span className={`text-lg font-bold ${isPassed ? 'text-green-600' : 'text-red-600'}`}>
                                        {p.quizScore}%
                                      </span>
                                      <span className="text-[10px] text-gray-400">
                                        ({p.quizCorrectAnswers}/{p.quizTotalQuestions})
                                      </span>
                                    </div>
                                  ) : (
                                    <span className="text-xs text-gray-400">Belum ujian</span>
                                  )}
                                </div>
                              </div>
                              
                              <div className="flex gap-1">
                                <Button size="sm" variant="outline" onClick={() => updateParticipantStatus(p.id, 'approved')} className="flex-1 h-7 text-[10px] text-green-600 hover:text-green-700 border-green-200 bg-green-50">✓ Setujui</Button>
                                <Button size="sm" variant="outline" onClick={() => updateParticipantStatus(p.id, 'rejected')} className="flex-1 h-7 text-[10px] text-red-600 hover:text-red-700 border-red-200 bg-red-50">✗ Tolak</Button>
                                <Button size="sm" variant="ghost" onClick={() => deleteParticipant(p.id, p.fullName)} className="h-7 w-7 p-0 text-gray-400 hover:text-red-600 hover:bg-red-50"><Trash2 className="w-3 h-3" /></Button>
                              </div>
                            </div>
                          </Card>
                        );
                      })}
                    </div>
                  </ScrollArea>
                )}
              </div>
              
              {/* Desktop Table View */}
              <Card className="hidden md:block">
                <CardContent className="p-0">
                  <ScrollArea className="h-[400px] md:h-[500px] custom-scrollbar">
                    <div className="overflow-x-auto">
                      <Table className="min-w-[700px]">
                      <TableHeader className="sticky top-0 bg-white">
                        <TableRow>
                          <TableHead>Nama Lengkap</TableHead>
                          <TableHead>Sekolah/Kelas</TableHead>
                          <TableHead>Jenis Kelamin</TableHead>
                          <TableHead>Tinggi/Berat</TableHead>
                          <TableHead>Nilai Ujian</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Aksi</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {participants.map((p) => {
                          const passingScore = parseInt(settings.quiz_passing_score) || 70;
                          const isPassed = p.quizScore !== null && p.quizScore >= passingScore;
                          
                          return (
                            <TableRow key={p.id}>
                              <TableCell className="font-medium">
                                <div>{p.fullName}<div className="text-xs text-gray-500">{p.email}</div></div>
                              </TableCell>
                              <TableCell><div>{p.school}<div className="text-xs text-gray-500">Kelas {p.class}</div></div></TableCell>
                              <TableCell>{p.gender}</TableCell>
                              <TableCell>{p.height} cm / {p.weight} kg</TableCell>
                              <TableCell>
                                {p.quizScore !== null ? (
                                  <div className="flex flex-col">
                                    <span className={`font-bold ${isPassed ? 'text-green-600' : 'text-red-600'}`}>
                                      {p.quizScore}%
                                    </span>
                                    <span className="text-xs text-gray-500">
                                      {p.quizCorrectAnswers}/{p.quizTotalQuestions} benar
                                    </span>
                                    <span className="text-xs text-gray-400">
                                      {Math.floor(p.quizTimeSpent! / 60)}:{(p.quizTimeSpent! % 60).toString().padStart(2, '0')} menit
                                    </span>
                                  </div>
                                ) : (
                                  <span className="text-gray-400 text-sm">Belum ujian</span>
                                )}
                              </TableCell>
                              <TableCell>
                                <Badge className={p.status === 'approved' ? 'bg-green-500' : p.status === 'rejected' ? 'bg-red-500' : 'bg-yellow-500'}>
                                  {p.status === 'approved' ? 'Disetujui' : p.status === 'rejected' ? 'Ditolak' : 'Pending'}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex gap-1 md:gap-2">
                                  <Button size="sm" variant="outline" onClick={() => updateParticipantStatus(p.id, 'approved')} className="text-green-600 hover:text-green-700 px-2">✓</Button>
                                  <Button size="sm" variant="outline" onClick={() => updateParticipantStatus(p.id, 'rejected')} className="text-red-600 hover:text-red-700 px-2">✗</Button>
                                  <Button size="sm" variant="ghost" onClick={() => deleteParticipant(p.id, p.fullName)} className="text-gray-400 hover:text-red-600 px-2"><Trash2 className="w-4 h-4" /></Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                        {participants.length === 0 && (
                          <TableRow><TableCell colSpan={7} className="text-center text-gray-500 py-8">Belum ada peserta terdaftar</TableCell></TableRow>
                        )}
                      </TableBody>
                    </Table>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Questions Tab */}
            <TabsContent value="questions">
              <h2 className="text-lg md:text-2xl font-bold mb-4 md:mb-6">Manajemen Soal</h2>
              <AddQuestionForm />
              <Card>
                <CardContent className="p-0">
                  <ScrollArea className="h-[300px] md:h-[400px] custom-scrollbar">
                    <div className="overflow-x-auto">
                      <Table className="min-w-[500px]">
                      <TableHeader>
                        <TableRow><TableHead>Soal</TableHead><TableHead>Jawaban</TableHead><TableHead>Status</TableHead><TableHead>Aksi</TableHead></TableRow>
                      </TableHeader>
                      <TableBody>
                        {questions.map((q) => (
                          <TableRow key={q.id}>
                            <TableCell className="max-w-md truncate">{q.question}</TableCell>
                            <TableCell><Badge variant="outline">{q.answer}</Badge></TableCell>
                            <TableCell><Badge className={q.isActive ? 'bg-green-500' : 'bg-gray-400'}>{q.isActive ? 'Aktif' : 'Nonaktif'}</Badge></TableCell>
                            <TableCell><Button size="sm" variant="ghost" onClick={() => deleteQuestion(q.id)} className="text-red-600 hover:text-red-700"><Trash2 className="w-4 h-4" /></Button></TableCell>
                          </TableRow>
                        ))}
                        {questions.length === 0 && <TableRow><TableCell colSpan={4} className="text-center text-gray-500 py-8">Belum ada soal</TableCell></TableRow>}
                      </TableBody>
                    </Table>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Songs Tab */}
            <TabsContent value="songs">
              <h2 className="text-lg md:text-2xl font-bold mb-4 md:mb-6">Lagu Nasional</h2>
              <AddSongForm />
              <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table className="min-w-[400px]">
                    <TableHeader><TableRow><TableHead>Judul</TableHead><TableHead>Status</TableHead><TableHead>Aksi</TableHead></TableRow></TableHeader>
                    <TableBody>
                      {songs.map((s) => (
                        <TableRow key={s.id}>
                          <TableCell className="font-medium">{s.title}</TableCell>
                          <TableCell><Badge className={s.isActive ? 'bg-green-500' : 'bg-gray-400'}>{s.isActive ? 'Aktif' : 'Nonaktif'}</Badge></TableCell>
                          <TableCell>
                            <Button size="sm" variant="ghost" onClick={async () => {
                              if (confirm('Yakin ingin menghapus lagu ini?')) {
                                const res = await fetch(`/api/admin/songs/${s.id}`, { method: 'DELETE' });
                                if (res.ok) { toast.success('Lagu berhasil dihapus'); fetchData(); }
                              }
                            }} className="text-red-600 hover:text-red-700"><Trash2 className="w-4 h-4" /></Button>
                          </TableCell>
                        </TableRow>
                      ))}
                      {songs.length === 0 && <TableRow><TableCell colSpan={3} className="text-center text-gray-500 py-8">Belum ada lagu</TableCell></TableRow>}
                    </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Announcements Tab */}
            <TabsContent value="announcements">
              <h2 className="text-lg md:text-2xl font-bold mb-4 md:mb-6">Pengumuman</h2>
              <AddAnnouncementForm />
              <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table className="min-w-[500px]">
                    <TableHeader><TableRow><TableHead>Judul</TableHead><TableHead>Isi</TableHead><TableHead>Status</TableHead><TableHead>Aksi</TableHead></TableRow></TableHeader>
                    <TableBody>
                      {adminAnnouncements.map((a) => (
                        <TableRow key={a.id}>
                          <TableCell className="font-medium">{a.title}</TableCell>
                          <TableCell className="max-w-xs truncate">{a.content}</TableCell>
                          <TableCell><Badge className={a.isActive ? 'bg-green-500' : 'bg-gray-400'}>{a.isActive ? 'Aktif' : 'Nonaktif'}</Badge></TableCell>
                          <TableCell>
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline" onClick={async () => {
                                await fetch(`/api/admin/announcements/${a.id}`, {
                                  method: 'PATCH',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ isActive: !a.isActive }),
                                });
                                fetchData();
                              }}>{a.isActive ? 'Nonaktifkan' : 'Aktifkan'}</Button>
                              <Button size="sm" variant="ghost" onClick={async () => {
                                if (confirm('Yakin ingin menghapus pengumuman ini?')) {
                                  const res = await fetch(`/api/admin/announcements/${a.id}`, { method: 'DELETE' });
                                  if (res.ok) { toast.success('Pengumuman berhasil dihapus'); fetchData(); }
                                }
                              }} className="text-red-600 hover:text-red-700"><Trash2 className="w-4 h-4" /></Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                      {adminAnnouncements.length === 0 && <TableRow><TableCell colSpan={4} className="text-center text-gray-500 py-8">Belum ada pengumuman</TableCell></TableRow>}
                    </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Settings Tab */}
            <TabsContent value="settings">
              <h2 className="text-lg md:text-2xl font-bold mb-4 md:mb-6">Pengaturan Teks</h2>
              <p className="text-gray-500 text-sm mb-4 md:mb-6">Ubah teks yang ditampilkan pada halaman website</p>
              <SettingsForm />
            </TabsContent>

            {/* Credentials Tab */}
            <TabsContent value="credentials">
              <CredentialsForm />
            </TabsContent>
          </Tabs>
        </main>

        <footer className="bg-gray-100 border-t py-3 md:py-4 text-center text-gray-600 text-xs md:text-sm">
          <p>Admin Panel Seleksi Paskibraka © 2024</p>
        </footer>
      </div>
    );
  };

  return (
    <>
      {/* Announcement Banner - shown on all pages except admin */}
      {currentPage !== 'admin' && currentPage !== 'admin-login' && (
        <AnnouncementBanner announcements={announcements} />
      )}
      
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          {currentPage === 'landing' && <LandingPage />}
          {currentPage === 'login' && <LoginPage />}
          {currentPage === 'register' && <RegisterPage />}
          {currentPage === 'dashboard' && currentUser && <DashboardPage />}
          {currentPage === 'quiz' && currentUser && <QuizPage />}
          {currentPage === 'admin-login' && <AdminLoginPage />}
          {currentPage === 'admin' && <AdminPanel />}
        </motion.div>
      </AnimatePresence>
    </>
  );
}
