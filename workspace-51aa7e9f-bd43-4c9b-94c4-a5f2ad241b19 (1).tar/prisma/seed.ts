import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Create admin user
  const admin = await prisma.admin.upsert({
    where: { username: 'admin' },
    update: {},
    create: {
      username: 'admin',
      password: 'admin123',
    },
  });
  console.log('Admin created:', admin.username);

  // Create demo participant users
  const users = await Promise.all([
    prisma.participantUser.upsert({
      where: { username: 'peserta1' },
      update: {},
      create: {
        username: 'peserta1',
        password: 'password1',
      },
    }),
    prisma.participantUser.upsert({
      where: { username: 'peserta2' },
      update: {},
      create: {
        username: 'peserta2',
        password: 'password2',
      },
    }),
    prisma.participantUser.upsert({
      where: { username: 'demo' },
      update: {},
      create: {
        username: 'demo',
        password: 'demo',
      },
    }),
  ]);
  console.log('Participant users created:', users.length);

  // Create sample questions
  const questions = await Promise.all([
    prisma.question.create({
      data: {
        question: 'Apa arti dari Paskibraka?',
        optionA: 'Pasukan Pengibar Bendera',
        optionB: 'Pasukan Pengibar Bunga',
        optionC: 'Pasukan Pengawal Bendera',
        optionD: 'Pasukan Pengawal Bangsa',
        answer: 'A',
      },
    }),
    prisma.question.create({
      data: {
        question: 'Bendera Indonesia memiliki warna...',
        optionA: 'Hijau-Putih',
        optionB: 'Merah-Putih',
        optionC: 'Biru-Putih',
        optionD: 'Kuning-Putih',
        answer: 'B',
      },
    }),
    prisma.question.create({
      data: {
        question: 'Lambang negara Indonesia adalah...',
        optionA: 'Garuda',
        optionB: 'Komodo',
        optionC: 'Harimau',
        optionD: 'Elang',
        answer: 'A',
      },
    }),
  ]);
  console.log('Questions created:', questions.length);

  // Create sample participants with complete data
  const participants = await Promise.all([
    prisma.participant.create({
      data: {
        // Data Akun
        username: 'peserta1',
        email: 'ahmad@example.com',
        
        // Data Diri
        fullName: 'Ahmad Rizki Pratama',
        placeOfBirth: 'Jakarta',
        dateOfBirth: '2008-05-15',
        gender: 'Laki-laki',
        religion: 'Islam',
        
        // Data Fisik
        height: '168',
        weight: '55',
        
        // Data Sekolah
        school: 'SMA Negeri 1 Jakarta',
        class: 'XI',
        
        // Data Kontak
        phone: '08123456789',
        address: 'Jl. Merdeka No. 10, Jakarta Pusat',
        
        // Status
        userId: users[0].id,
        status: 'approved',
      },
    }),
    prisma.participant.create({
      data: {
        // Data Akun
        username: 'peserta2',
        email: 'siti@example.com',
        
        // Data Diri
        fullName: 'Siti Nurhaliza',
        placeOfBirth: 'Bandung',
        dateOfBirth: '2008-08-20',
        gender: 'Perempuan',
        religion: 'Islam',
        
        // Data Fisik
        height: '160',
        weight: '48',
        
        // Data Sekolah
        school: 'SMA Negeri 2 Bandung',
        class: 'XI',
        
        // Data Kontak
        phone: '08123456788',
        address: 'Jl. Asia Afrika No. 15, Bandung',
        
        // Status
        userId: users[1].id,
        status: 'pending',
      },
    }),
  ]);
  console.log('Participants created:', participants.length);

  console.log('\n=== SEED DATA COMPLETED ===');
  console.log('Admin Login: admin / admin123');
  console.log('Participant Login: demo / demo');
  console.log('Participant Login: peserta1 / password1');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
